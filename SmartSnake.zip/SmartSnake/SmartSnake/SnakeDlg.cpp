#include "stdafx.h"
#include "SmartSnake.h"
#include "SnakeDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

DWORD WINAPI ThreadFood(LPVOID lpParameter);//����ʳ���߳�.

CSnakeDlg::CSnakeDlg(CWnd* pParent)
	: CDialogEx(CSnakeDlg::IDD, pParent),
	m_snake(m_rc,m_po,m_sp)
{
	m_rc.left=0;
	m_rc.right=500;
	m_rc.top=50;
	m_rc.bottom=350;
	m_po.x=20;
	m_po.y=20;
	m_sp=SP_NORMAL;
	m_snake=Snake(m_rc,m_po,m_sp);
	m_dr=DR_RIGHT;
	m_ispc=false;
	m_foodok=true;
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSnakeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CSnakeDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BEGIN, &CSnakeDlg::OnBnClickedBegin)
	ON_BN_CLICKED(IDC_RESTART, &CSnakeDlg::OnBnClickedRestart)
	ON_BN_CLICKED(IDC_OPENG, &CSnakeDlg::OnBnClickedOpeng)
	ON_BN_CLICKED(IDC_CLOSEG, &CSnakeDlg::OnBnClickedCloseg)
	ON_BN_CLICKED(IDC_QUIT, &CSnakeDlg::OnBnClickedQuit)
	ON_WM_KEYDOWN()
	ON_WM_ERASEBKGND()
	ON_WM_TIMER()
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()

BOOL CSnakeDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	CWnd *close=GetDlgItem(IDC_CLOSEG);
	close->EnableWindow(false);
	CreateGoodFood();

	return TRUE;
}

void CSnakeDlg::OnPaint()
{
	CPaintDC dc(this);
	ShowSnake(dc);
	CDialogEx::OnPaint();
}

//��ֹ�û�����ENTER���˳�..
void CSnakeDlg::OnOK(){}

void CSnakeDlg::ShowSnake(CDC &dc)
{
	HBRUSH hBrush = CreateSolidBrush(RGB(0,0,0));
	dc.SelectObject(hBrush);
	CPen pen(PS_SOLID,0,RGB(200,200,200)); 
	dc.SelectObject(&pen);
	dc.Rectangle(&m_rc);

	hBrush = CreateSolidBrush(RGB(200,200,200));
	dc.SelectObject(hBrush);
	dc.Ellipse(&m_food);

	list<SnakeNode>::iterator be=m_snake.m_snake.begin();
	for(unsigned i=0;i<m_snake.m_snake.size();i++,be++)
	{
		dc.Rectangle(&be->rc);
	}
}

void CSnakeDlg::CreateFood()
{
	srand((unsigned)time(0));
	int x=rand()%25;
	int y=rand()%15;
	m_food.left=m_po.x*x;
	m_food.top=50+m_po.y*y;
	m_food.right=m_food.left+m_po.x;
	m_food.bottom=m_food.top+m_po.y;
}

void CSnakeDlg::CreateGoodFood()
{
	CreateFood();
	list<SnakeNode>::iterator iter=m_snake.m_snake.begin();
	for(unsigned i=0;i<m_snake.m_snake.size();i++,iter++)
	{
		if(m_food.left==iter->rc.left&&
			m_food.top==iter->rc.top)
		{
			CreateFood();
			iter=m_snake.m_snake.begin();
			i=0;
		}
	}
}

void CSnakeDlg::SetDire()
{
	XY size;
	size.x=15;
	size.y=25;
	bool maze[15][25];
	memset(maze,0,sizeof(maze));
	list<SnakeNode>::iterator iter=m_snake.m_snake.begin();
	for(unsigned i=0;i<m_snake.m_snake.size();i++,iter++)
	{
		XY curpo;
		curpo.y=iter->rc.left/m_po.x;
		curpo.x=(iter->rc.top-50)/m_po.y;
		maze[curpo.x][curpo.y]=1;
	}

	RECT rect=m_snake.m_snake.back().rc;
	XY st;
	st.y=rect.left/m_po.x;
	st.x=(rect.top-50)/m_po.y;
	XY en;
	en.y=m_food.left/m_po.x;
	en.x=(m_food.top-50)/m_po.y;
	m_bfs.InitBfs((bool**)maze,size);
	m_bfs.EetBfs(st,en);
}

//��ʼ��Ϸ
void CSnakeDlg::OnBnClickedBegin()
{
	CWnd *begin=GetDlgItem(IDC_BEGIN);
	begin->EnableWindow(false);
	m_tim=SetTimer(1,100,NULL);
	m_dr=DR_RIGHT;//��ʼ���������
}

//��ͣ��Ϸ
void CSnakeDlg::OnBnClickedRestart()
{
	CWnd *begin=GetDlgItem(IDC_BEGIN);
	begin->EnableWindow(true);
	KillTimer(m_tim);
}

//�������
void CSnakeDlg::OnBnClickedOpeng()
{
	CWnd *close=GetDlgItem(IDC_CLOSEG);
	CWnd *open=GetDlgItem(IDC_OPENG);
	close->EnableWindow(true);
	open->EnableWindow(false);
	m_ispc=true;
}

//�ر����..
void CSnakeDlg::OnBnClickedCloseg()
{
	CWnd *close=GetDlgItem(IDC_CLOSEG);
	CWnd *open=GetDlgItem(IDC_OPENG);
	close->EnableWindow(false);
	open->EnableWindow(true);
	m_ispc=false;
}

//�˳���Ϸ..
void CSnakeDlg::OnBnClickedQuit()
{
	CDialogEx::OnCancel();
}

BOOL CSnakeDlg::PreTranslateMessage(MSG* pMsg)
{
	if(m_ispc)//��������Ϣ..
		return CDialog::PreTranslateMessage(pMsg);
	//��ȡ�ĸ������
	switch(pMsg->wParam)
	{
	case VK_UP:
		m_dr=DR_UP;
		return true;
		break;
	case VK_DOWN:
		m_dr=DR_DOWN;
		return true;
		break;
	case VK_LEFT:
		m_dr=DR_LEFT;
		return true;
		break;
	case VK_RIGHT:
		m_dr=DR_RIGHT;
		return true;
		break;
	}
	return CDialog::PreTranslateMessage(pMsg);
}

void CSnakeDlg::OnTimer(UINT_PTR nIDEvent)
{
	if(nIDEvent==m_tim)
	{
		

		if(m_snake.GameOver())
		{
			KillTimer(m_tim);
			MessageBox(L"��Ϸ����!\n���ȷ�����¿�ʼ��Ϸ.",L"״̬");
			m_snake.m_snake.clear();
			m_snake=Snake(m_rc,m_po,m_sp);

			CWnd *begin=GetDlgItem(IDC_BEGIN);
			begin->EnableWindow(true);
			CreateGoodFood();
			CDialogEx::OnTimer(nIDEvent);
			return;
		}
		if(m_ispc)
		{
			SetDire();
			XY cur=m_bfs.m_que.front();
			m_bfs.m_que.pop();
			
			RECT rc=m_snake.m_snake.back().rc;
			XY head;
			head.y=rc.left/m_po.x;
			head.x=(rc.top-50)/m_po.y;
			if(cur.x==head.x)
			{
				if(cur.y-head.y==1)
					m_dr=DR_RIGHT;
				else if(cur.y-head.y==-1)
					m_dr=DR_LEFT;
			}
			else if(cur.y==head.y)
			{
				if(cur.x-head.x==1)
					m_dr=DR_DOWN;
				else if(cur.x-head.x==-1)
					m_dr=DR_UP;
			}
			else
			{
				m_dr=GetSafeDire();
			}
			if(!IsSafe())
			{
				/*KillTimer(m_tim);
				MessageBox(L"����ȫ!",L"����");*/
				m_dr=GetSafeDire();
			}
		}
		
		if(m_foodok&&m_snake.SMove(m_dr,m_food))
		{
			m_foodok=false;//ʳ���Ѿ�������.
			//CreateGoodFood();
			//SetDire();
		}

		//����ʳ��..
		HANDLE hThreadFD=::CreateThread(NULL,0,ThreadFood,this,0,NULL);
		::CloseHandle(hThreadFD);

		InvalidateRect(&m_rc);
	}
	CDialogEx::OnTimer(nIDEvent);
}


BOOL CSnakeDlg::OnEraseBkgnd(CDC* pDC)
{
	return false;
}


bool CSnakeDlg::IsSafe()
{
	//�����·���������..
	queue<XY> tque=m_bfs.m_que;
	Snake tsna(m_snake);
	while(!tque.empty())//���в�Ϊ��
	{
		XY txy=tque.front();
		tque.pop();
		SnakeNode node;
		node.rc.left=txy.y*20;
		node.rc.top=txy.x*20+50;
		node.rc.right=node.rc.left+20;
		node.rc.bottom=node.rc.top+20;
		node.curDire=DR_LEFT;//����ʼ��һ�����򼴿�..

		tsna.m_snake.push_back(node);
		tsna.m_snake.pop_front();
	}

	XY size;
	size.x=15;
	size.y=25;
	bool maze[15][25];
	memset(maze,0,sizeof(maze));
	list<SnakeNode>::iterator iter=++tsna.m_snake.begin();
	for(unsigned i=1;i<tsna.m_snake.size()-1;i++,iter++)
	{
		XY curpo;
		curpo.y=iter->rc.left/20;
		curpo.x=(iter->rc.top-50)/20;
		maze[curpo.x][curpo.y]=1;
	}

	RECT rect=tsna.m_snake.back().rc;
	RECT rect2=tsna.m_snake.front().rc;
	XY st;
	st.y=rect.left/m_po.x;
	st.x=(rect.top-50)/m_po.y;
	XY en;
	en.y=rect2.left/m_po.x;
	en.x=(rect2.top-50)/m_po.y;
	m_bfs.InitBfs((bool**)maze,size);
	if(m_bfs.CalcBfs(st,en))
		return true;
	return false;

}

DIRE CSnakeDlg::GetSafeDire()
{
	//�õ���ǰ��ͼ
	XY size;
	size.x=15;
	size.y=25;
	bool maze[15][25];
	memset(maze,0,sizeof(maze));
	list<SnakeNode>::iterator iter=m_snake.m_snake.begin();
	for(unsigned i=0;i<m_snake.m_snake.size();i++,iter++)
	{
		XY curpo;
		curpo.y=iter->rc.left/m_po.x;
		curpo.x=(iter->rc.top-50)/m_po.y;
		maze[curpo.x][curpo.y]=1;
	}
	//�õ���ͷ����β.
	RECT rect=m_snake.m_snake.back().rc;
	//RECT rect2=m_snake.m_snake.front().rc;
	XY st;
	st.y=rect.left/20;
	st.x=(rect.top-50)/20;
	//XY en;
	//en.y=rect2.left/m_po.x;
	//en.x=(rect2.top-50)/m_po.y;

	XY next=st;
	next.x++;
	if(next.x<15&&maze[next.x][next.y]==0)
	{
		return DR_DOWN;
	}
	next=st;
	next.y++;
	if(next.y<25&&maze[next.x][next.y]==0)
	{
		return DR_RIGHT;
	}
	next=st;
	next.x--;
	if(next.x>=0&&maze[next.x][next.y]==0)
	{
		return DR_UP;
	}
	next=st;
	next.y--;
	if(next.y>=0&&maze[next.x][next.y]==0)
	{
		return DR_LEFT;
	}
	return DR_UP;
}

DWORD WINAPI ThreadFood(LPVOID lpParameter)
{
	CSnakeDlg *dlg=(CSnakeDlg*)lpParameter;

	if(!dlg->m_foodok)
	{
		dlg->CreateGoodFood();
		dlg->m_foodok=true;
	}
	return 0;
}